# barras
arquivos necessários para as barras horizontal e vertical.
